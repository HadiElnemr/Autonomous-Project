#!/usr/bin/env python3

import rospy

rospy.init_node("Validation_Printing_Node_Team_18")

print("Hello World")
